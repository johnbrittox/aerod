<?php
session_start();
require_once 'dataon/config.php';

$db = Database::getInstance();
$conn = $db->getConnection();



// Generate CAPTCHA on first load or refresh
if (!isset($_SESSION['captcha']) || isset($_GET['refresh_captcha'])) {
    generate_captcha();
}

$errors = [];
$success = '';

// Handle Registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    try {
        $name = sanitize_input($_POST['name']);
        $username = sanitize_input($_POST['reg_username']);
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'];
        $captcha = sanitize_input($_POST['captcha']);
        
        // Validate CAPTCHA first
        if (!verify_captcha($captcha)) {
            generate_captcha(); // Generate new captcha
            throw new Exception("Invalid or expired CAPTCHA code. A new code has been generated.");
        }
        
        // Validate inputs
        if (empty($name) || empty($username) || empty($email) || empty($password)) {
            throw new Exception("All fields are required");
        }
        
        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }
        
        // Validate username (phone number)
        if (!preg_match('/^[0-9]{10,15}$/', $username)) {
            throw new Exception("Username must be a valid phone number (10-15 digits)");
        }
        
        // Check if phone is blocked
        if (is_phone_blocked($username, $conn)) {
            throw new Exception("This phone number is blocked");
        }
        
        // Validate password strength
        if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
            throw new Exception("Password must be at least 8 characters with letters and numbers");
        }
        
        // Check if username exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            throw new Exception("Username already exists");
        }
        
        // Check if email exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            throw new Exception("Email already registered");
        }
        
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert user
        $stmt = $conn->prepare("INSERT INTO users (name, username, email, password, phone) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $username, $email, $hashed_password, $username]);
        
        $success = "Registration successful! Please login.";
        generate_captcha(); // Regenerate CAPTCHA
        
    } catch (Exception $e) {
        $errors[] = $e->getMessage();
        generate_captcha(); // Generate new captcha on error
    }
}

// Handle Login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    try {
        $username = sanitize_input($_POST['login_username']);
        $password = $_POST['login_password'];
        $ip = $_SERVER['REMOTE_ADDR'];
        
        // Check login attempts
        if (!check_login_attempts($username, $ip, $conn)) {
            throw new Exception("Too many failed login attempts. Please try again in 30 minutes.");
        }
        
        // Validate inputs
        if (empty($username) || empty($password)) {
            throw new Exception("Username and password are required");
        }
        
        // Check credentials
        $stmt = $conn->prepare("SELECT id, name, username, password FROM users WHERE username = ? AND is_active = 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            // Login successful
            log_login_attempt($username, $ip, 1, $conn);
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['last_activity'] = time();
            
            header("Location: account.php");
            exit();
        } else {
            log_login_attempt($username, $ip, 0, $conn);
            throw new Exception("Invalid username or password");
        }
        
    } catch (Exception $e) {
        $errors[] = $e->getMessage();
    }
}

// AJAX Username Check
if (isset($_POST['check_username'])) {
    $username = sanitize_input($_POST['username']);
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    echo json_encode(['exists' => $stmt->fetch() !== false]);
    exit();
}

// AJAX CAPTCHA Refresh
if (isset($_POST['refresh_captcha'])) {
    generate_captcha();
    echo json_encode(['captcha' => $_SESSION['captcha']]);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Register / Login - Aero Dimensions</title>
    <meta name="description" content="Register or login to access Aero Dimensions services and portal">
    <meta name="keywords" content="Aero Dimensions, Registration, Login, Aerospace, Kerala">
    
    <!-- favicons Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/favicons/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicons/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicons/favicon-16x16.png" />
    <link rel="manifest" href="assets/images/favicons/site.webmanifest" />

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,100..900;1,100..900&family=Heebo:wght@100..900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/01-bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/02-animate.min.css" />
    <link rel="stylesheet" href="assets/css/03-custom-animate.css" />
    <link rel="stylesheet" href="assets/css/05-flaticon.css" />
    <link rel="stylesheet" href="assets/css/06-font-awesome-all.css" />
    <link rel="stylesheet" href="assets/css/07-jarallax.css" />
    <link rel="stylesheet" href="assets/css/08-jquery.magnific-popup.css" />
    <link rel="stylesheet" href="assets/css/09-nice-select.css" />
    <link rel="stylesheet" href="assets/css/10-odometer.min.css" />
    <link rel="stylesheet" href="assets/css/11-owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/12-owl.theme.default.min.css" />
    <link rel="stylesheet" href="assets/css/13-jquery-ui.css" />
    <link rel="stylesheet" href="assets/css/twentytwenty.css" />

    <link rel="stylesheet" href="assets/css/module-css/01-slider.css" />
    <link rel="stylesheet" href="assets/css/module-css/02-about.css" />
    <link rel="stylesheet" href="assets/css/module-css/03-services.css" />
    <link rel="stylesheet" href="assets/css/module-css/04-testimonial.css" />
    <link rel="stylesheet" href="assets/css/module-css/05-team.css" />
    <link rel="stylesheet" href="assets/css/module-css/06-blog.css" />
    <link rel="stylesheet" href="assets/css/module-css/07-contact.css" />
    <link rel="stylesheet" href="assets/css/module-css/08-counter.css" />
    <link rel="stylesheet" href="assets/css/module-css/09-error.css" />
    <link rel="stylesheet" href="assets/css/module-css/10-faq.css" />
    <link rel="stylesheet" href="assets/css/module-css/11-footer.css" />
    <link rel="stylesheet" href="assets/css/module-css/12-page-header.css" />
    <link rel="stylesheet" href="assets/css/module-css/13-shop.css" />
    <link rel="stylesheet" href="assets/css/module-css/14-video.css" />
    <link rel="stylesheet" href="assets/css/swiper.min.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
    
    <style>
        .page-header--register {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            padding: 120px 0 80px;
            position: relative;
        }
        
        .page-header--register::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url(assets/images/backgrounds/page-header-bg.jpg);
            opacity: 0.1;
            z-index: 0;
        }
        
        .page-header__inner {
            position: relative;
            z-index: 1;
        }
        
        .page-header__title {
            color: #ffffff;
            font-size: 48px;
            font-weight: 700;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .page-header__text {
            color: rgba(255, 255, 255, 0.9);
            font-size: 16px;
            text-align: center;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .register-section {
            padding: 80px 0;
            background: #f8f9fa;
        }
        
        .register-box {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 40px;
        }
        
        .register-tabs {
            display: flex;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        }
        
        .register-tabs .tab-btn {
            flex: 1;
            padding: 25px;
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            background: transparent;
            transition: all 0.3s;
            position: relative;
        }
        
        .register-tabs .tab-btn:hover {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .register-tabs .tab-btn.active-btn {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.15);
        }
        
        .register-tabs .tab-btn.active-btn::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: #ffffff;
        }
        
        .register-body {
            padding: 50px;
        }
        
        .tab {
            display: none;
        }
        
        .tab.active-tab {
            display: block;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s;
            background: #ffffff;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #2a5298;
            box-shadow: 0 0 0 3px rgba(42, 82, 152, 0.1);
        }
        
        .password-generator {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .password-generator input {
            flex: 1;
        }
        
        .btn-generate {
            padding: 15px 20px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            white-space: nowrap;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-generate:hover {
            background: #218838;
            transform: translateY(-2px);
        }
        
        .captcha-box {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .captcha-wrapper {
            position: relative;
            display: inline-block;
        }
        
        .captcha-display {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border: 3px solid #2a5298;
            padding: 18px 35px;
            border-radius: 10px;
            font-size: 32px;
            font-weight: bold;
            letter-spacing: 10px;
            font-family: 'Courier New', monospace;
            color: #2a5298;
            user-select: none;
            text-align: center;
            min-width: 200px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
            position: relative;
        }
        
        .captcha-display::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: repeating-linear-gradient(
                45deg,
                transparent,
                transparent 10px,
                rgba(42, 82, 152, 0.03) 10px,
                rgba(42, 82, 152, 0.03) 20px
            );
            pointer-events: none;
        }
        
        .btn-refresh-captcha {
            position: absolute;
            top: -10px;
            right: -10px;
            width: 35px;
            height: 35px;
            background: #28a745;
            color: white;
            border: 2px solid white;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            transition: all 0.3s;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
        
        .btn-refresh-captcha:hover {
            background: #218838;
            transform: rotate(180deg);
        }
        
        .captcha-box input {
            flex: 1;
            min-width: 200px;
        }
        
        .alert {
            padding: 18px 25px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-size: 14px;
            line-height: 1.6;
        }
        
        .alert-danger {
            background: #fff3cd;
            border: 1px solid #ffc107;
            color: #856404;
        }
        
        .alert-success {
            background: #d4edda;
            border: 1px solid #28a745;
            color: #155724;
        }
        
        .username-check {
            font-size: 13px;
            margin-top: 8px;
            font-weight: 600;
        }
        
        .username-available {
            color: #28a745;
        }
        
        .username-taken {
            color: #dc3545;
        }
        
        .thm-btn-register {
            width: 100%;
            padding: 18px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        
        .thm-btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(42, 82, 152, 0.3);
        }
        
        .thm-btn-register i {
            margin-left: 10px;
        }
        
        .faq-section {
            background: white;
            border-radius: 15px;
            padding: 50px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        
        .faq-section h3 {
            color: #2a5298;
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 40px;
            text-align: center;
        }
        
        .faq-item {
            margin-bottom: 25px;
            border-bottom: 1px solid #e0e0e0;
            padding-bottom: 25px;
        }
        
        .faq-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .faq-question {
            font-weight: 600;
            color: #333;
            font-size: 16px;
            margin-bottom: 12px;
        }
        
        .faq-answer {
            color: #666;
            line-height: 1.8;
            font-size: 14px;
        }
        
        @media (max-width: 768px) {
            .page-header__title {
                font-size: 32px;
            }
            
            .register-body {
                padding: 30px 20px;
            }
            
            .faq-section {
                padding: 30px 20px;
            }
            
            .register-tabs .tab-btn {
                font-size: 16px;
                padding: 20px 15px;
            }
            
            .password-generator {
                flex-direction: column;
            }
            
            .btn-generate {
                width: 100%;
            }
            
            .captcha-box {
                flex-direction: column;
            }
            
            .captcha-display {
                width: 100%;
                font-size: 28px;
                letter-spacing: 8px;
            }
        }
    </style>
</head>

<body class="custom-cursor">
    <div class="custom-cursor__cursor"></div>
    <div class="custom-cursor__cursor-two"></div>

    <div class="page-wrapper">
        <!--Start Main Header One-->
        <header class="main-header-one main-header-one--three">
            <!--Start Main Header One Top-->
            <div class="main-header-one__top">
                <div class="container">
                    <div class="main-header-one__top-inner">
                        <ul class="header-style1__contact">
                            <li>
                                <div class="icon">
                                    <i class="icon-clock-1"></i>
                                </div>
                                <div class="text">
                                    <p>8:00 am - 5:00 pm - Sat - Sun</p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="icon-phone-call"></i>
                                </div>
                                <div class="text">
                                    <p><a href="tel:+917994641177">+91 7994641177</a></p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="icon-placeholder"></i>
                                </div>
                                <div class="text">
                                    <p>TC 79/1029
Attukal Trippadam , 
Muttathara
Vallakadavu , po 
Trivandrum
695008
</p>
                                </div>
                            </li>
                        </ul>
                        <div class="main-header-one__top-right">
                            <div class="header-style1__social-links">
                                <a href="#"><i class="icon-facebook-app-symbol"></i></a>
                                <a href="#"><i class="icon-twitter-1"></i></a>
                                <a href="#"><i class="icon-linkedin-big-logo"></i></a>
                                <a href="#"><i class="icon-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Main Header One Top-->

            <!--Start Main Header One Bottom-->
            <div class="main-header-one__bottom">
                <nav class="main-menu">
                    <div class="main-menu__wrapper">
                        <div class="container">
                            <div class="main-menu__wrapper-inner">
                                <div class="main-header-one__bottom-left">
                                    <div class="logo-one">
                                        <a href="index.html"><img src="assets/images/resources/logo.png" alt=""></a>
                                    </div>
                                </div>
                                <div class="main-header-one__bottom-middle">
                                    <div class="main-menu__main-menu-box">
                                        <a href="#" class="mobile-nav__toggler"><i class="fa fa-bars"></i></a>
                                        <ul class="main-menu__list">
                                            <li><a href="index.html">Home</a></li>
                                            <li><a href="about.html">About Us</a></li>
                                            <li><a href="services.html">Services</a></li>
                                            <li><a href="contact.html">Contact</a></li>
                                                <li><a href="register.php">Register / Login</a></li>

                                        </ul>
                                    </div>
                                </div>
                                <div class="main-header-one__bottom-right">
                                    <div class="main-header__btn">
                                        <a class="thm-btn" href="contact.html">Get a Quote
                                            <i class="icon-next"></i>
                                            <span class="hover-btn hover-bx"></span>
                                            <span class="hover-btn hover-bx2"></span>
                                            <span class="hover-btn hover-bx3"></span>
                                            <span class="hover-btn hover-bx4"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            <!--End Main Header One Bottom-->
        </header>
        <!--End Main Header One-->

        <div class="stricky-header stricky-header__one stricked-menu main-menu">
            <div class="sticky-header__content"></div>
        </div>

        <!--Start Page Header-->
        <section class="page-header--register">
            <div class="container">
                <div class="page-header__inner">
                    <h2 class="page-header__title">Registration Portal</h2>
                    <p class="page-header__text">Join us in shaping the future of aerospace technology</p>
                </div>
            </div>
        </section>
        <!--End Page Header-->

        <!--Start Register Section-->
        <section class="register-section">
            <div class="container">
                <div class="row">
                    <!-- Registration / Login Box -->
                    <div class="col-lg-8 offset-lg-2">
                        <div class="register-box">
                            <div class="register-tabs">
                                <button class="tab-btn active-btn" data-tab="#register-tab">
                                    <i class="icon-user-1"></i> New Registration
                                </button>
                                <button class="tab-btn" data-tab="#login-tab">
                                    <i class="icon-login"></i> Member Login
                                </button>
                            </div>
                            
                            <div class="register-body">
                                <?php if (!empty($errors)): ?>
                                    <div class="alert alert-danger">
                                        <?php foreach ($errors as $error): ?>
                                            <div><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($success): ?>
                                    <div class="alert alert-success">
                                        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="tabs-content">
                                    <!-- Registration Tab -->
                                    <div id="register-tab" class="tab active-tab">
                                        <form method="POST" action="" id="registerForm">
                                            <div class="form-group">
                                                <label>Full Name *</label>
                                                <input type="text" name="name" class="form-control" placeholder="Enter your full name" required>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Username (Phone Number) *</label>
                                                <input type="number" name="reg_username" id="reg_username" class="form-control" placeholder="Enter 10-15 digit phone number" pattern="[0-9]{10,15}" required>
                                                <div id="username-check" class="username-check"></div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Email Address *</label>
                                                <input type="email" name="email" class="form-control" placeholder="Enter your email address" required>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Password *</label>
                                                <div class="password-generator">
                                                    <input type="password" name="password" id="password" class="form-control" placeholder="Enter password (min 8 chars, letters & numbers)" required>
                                                    <button type="button" class="btn-generate" onclick="generatePassword()"><i class="fas fa-key"></i> Generate</button>
                                                    <button type="button" class="btn-generate" onclick="togglePassword()"><i class="fas fa-eye"></i></button>
                                                </div>
                                                <small style="color: #666; display: block; margin-top: 8px;">Password must be at least 8 characters with letters and numbers</small>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Security Code *</label>
                                                <div class="captcha-box">
                                                    <div class="captcha-wrapper">
                                                        <div class="captcha-display" id="captchaDisplay"><?php echo $_SESSION['captcha']; ?></div>
                                                        <button type="button" class="btn-refresh-captcha" onclick="refreshCaptcha()" title="Generate new code">
                                                            <i class="fas fa-sync-alt"></i>
                                                        </button>
                                                    </div>
                                                    <input type="text" name="captcha" class="form-control" placeholder="Enter code shown above" required maxlength="6" autocomplete="off">
                                                </div>
                                                <small style="color: #666; display: block; margin-top: 8px;">Click the refresh icon to generate a new code</small>
                                            </div>
                                            
                                            <button type="submit" name="register" class="thm-btn-register">
                                                Create Account <i class="icon-next"></i>
                                            </button>
                                        </form>
                                    </div>
                                    
                                    <!-- Login Tab -->
                                    <div id="login-tab" class="tab">
                                        <form method="POST" action="">
                                            <div class="form-group">
                                                <label>Username *</label>
                                                <input type="text" name="login_username" class="form-control" placeholder="Enter your username" required>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Password *</label>
                                                <input type="password" name="login_password" class="form-control" placeholder="Enter your password" required>
                                            </div>
                                            
                                            <button type="submit" name="login" class="thm-btn-register">
                                                Sign In <i class="icon-next"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- FAQ Section -->
                    <div class="col-lg-8 offset-lg-2">
                        <div class="faq-section">
                            <h3>Frequently Asked Questions</h3>
                            
                            <div class="faq-item">
                                <div class="faq-question"><i class="fas fa-question-circle" style="color: #2a5298; margin-right: 10px;"></i>What should I use as my username?</div>
                                <div class="faq-answer">Please use your phone number (10-15 digits) as your username. This helps us maintain unique user identification and enables better communication.</div>
                            </div>
                            
                            <div class="faq-item">
                                <div class="faq-question"><i class="fas fa-question-circle" style="color: #2a5298; margin-right: 10px;"></i>Can I register with the same email or phone number twice?</div>
                                <div class="faq-answer">No, each email address and phone number can only be registered once to maintain data integrity and prevent duplicate accounts.</div>
                            </div>
                            
                            <div class="faq-item">
                                <div class="faq-question"><i class="fas fa-question-circle" style="color: #2a5298; margin-right: 10px;"></i>What are the password requirements?</div>
                                <div class="faq-answer">Your password must be at least 8 characters long and contain both letters and numbers for enhanced security. You can use the password generator for a strong password.</div>
                            </div>
                            
                            <div class="faq-item">
                                <div class="faq-question"><i class="fas fa-question-circle" style="color: #2a5298; margin-right: 10px;"></i>What is the security code for?</div>
                                <div class="faq-answer">The security code (CAPTCHA) helps prevent automated bot registrations and ensures that only real humans can create accounts. A new random code is generated each time, and it expires after 5 minutes for security.</div>
                            </div>
                            
                            <div class="faq-item">
                                <div class="faq-question"><i class="fas fa-question-circle" style="color: #2a5298; margin-right: 10px;"></i>Is my information secure?</div>
                                <div class="faq-answer">Yes, we use industry-standard encryption and security measures to protect your data. Your password is encrypted using advanced hashing algorithms and we implement multiple security layers.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Register Section-->

        <!--Start Site Footer-->
        <footer class="site-footer site-footer--three">
            <div class="site-footer--three__pattern" style="background-image: url(assets/images/pattern/footer-v3-pattern.png);"></div>
            <!--Start Site Footer Top-->
            <div class="site-footer__top">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".0s">
                            <div class="footer-widget__single footer-widget__about">
                                <div class="site-footer__logo">
                                    <a href="index.html"><img src="assets/images/resources/logo2.png" alt=""></a>
                                </div>
                                <div class="footer-widget__about-text">
                                    <p>AeroDimensions provides innovative engineering solutions, specializing in aerospace and industrial technologies.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".1s">
                            <div class="footer-widget__single footer-widget__services">
                                <div class="title-box">
                                    <h2>Quick Links</h2>
                                    <div class="line"></div>
                                </div>
                                <ul class="footer-widget__services-list">
                                    <li><a href="index.html"><span class="icon-right-chevron"></span> Home</a></li>
                                    <li><a href="about.html"><span class="icon-right-chevron"></span> About Us</a></li>
                                    <li><a href="services.html"><span class="icon-right-chevron"></span> Services</a></li>
                                    <li><a href="contact.html"><span class="icon-right-chevron"></span> Contact</a></li>
                                        <li><a href="register.php"><span class="icon-right-chevron"></span>Register / Login</a></li>

                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".3s">
                            <div class="footer-widget__single footer-widget__contact">
                                <div class="title-box">
                                    <h2>Contact Info</h2>
                                    <div class="line"></div>
                                </div>
                                <ul class="footer-widget__contact-list">
                                    <li>
                                        <div class="icon-box">
                                            <span class="icon-placeholder"></span>
                                        </div>
                                        <div class="text-box">
                                            <p>TC 79/1029 ,
 Attukal Trippadam ,
Muttathara ,<br>
Vallakadavu po 
Trivandrum ,
695008</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".3s">
                            <div class="footer-widget__single footer-widget__contact">
                                <div class="title-box">
                                    <h2>Contact Info</h2>
                                    <div class="line"></div>
                                </div>
                                <ul class="footer-widget__contact-list">
                                    <li>
                                        <div class="icon-box">
                                            <span class="icon-phone-call"></span>
                                        </div>
                                        <div class="text-box"> 
    <p><a href="tel:+917994641177">+91 79946 41177</a></p>
    <p><a href="tel:+917356323713">+91 73563 23713</a></p>
    <p><a href="tel:+918301921693">+91 83019 21693</a></p>
</div>
                                    </li>
                                    <li>
                                        <div class="icon-box">
                                            <span class="icon-envelope"></span>
                                        </div>
                                        <div class="text-box">
                                            
                                            <p><a href="mailto:aerokerala2025@gmail.com">aerokerala2025@gmail.com</a></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Site Footer Top-->

            <!--Start Site Footer Bottom-->
            <div class="site-footer__bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="site-footer__bottom-inner">
                                <div class="site-footer__copyright">
                                    <p>Copyright © 2025 <a href="index.html">AeroDimensions</a>. All Rights Reserved.</p>
                                </div>
                                <ul class="site-footer__bottom-menu">
                                    <li style="color: white;">Design & Developed by<a href="https://neowebtec.com/"> Neoweb Technologies</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Site Footer Bottom-->
        </footer>
        <!--End Site Footer-->
    </div>

    <div class="mobile-nav__wrapper">
        <div class="mobile-nav__overlay mobile-nav__toggler"></div>
        <div class="mobile-nav__content">
            <span class="mobile-nav__close mobile-nav__toggler">
                <i class="fa fa-times"></i>
            </span>
            <div class="logobox">
                <a href="index.html" aria-label="logo image">
                    <img src="assets/images/resources/logo2.png" alt="Logo" />
                </a>
            </div>
            <div class="mobile-nav__container"></div>
            <ul class="mobile-nav__contact list-unstyled">
                <li>
                    <i class="icon-envelope"></i>
                    <a href="mailto:aerokerala2025@gmail.com">aerokerala2025@gmail.com</a>
                </li>
                <li>
                    <i class="icon-phone-call"></i>
                    <a href="tel:+917994641177">+91 7994641177</a>
                </li>
            </ul>
            <div class="mobile-nav__top">
                <div class="mobile-nav__social">
                    <a href="#" class="icon-facebook-app-symbol"></a>
                    <a href="#" class="icon-twitter-1"></a>
                    <a href="#" class="icon-instagram"></a>
                    <a href="#" class="icon-pinterest"></a>
                </div>
            </div>
        </div>
    </div>

    <div class="search-popup">
        <button class="close-search" aria-label="close search box" title="close search box">
            <span class="icon-plus-1"></span>
        </button>
        <form action="#" method="post">
            <div class="search-popup__group">
                <input type="text" name="search-field" id="searchField" placeholder="Search Here..." required>
                <button type="submit" aria-label="search products" title="search products">
                    <i class="icon-search-interface-symbol"></i>
                </button>
            </div>
        </form>
    </div>

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top">
        <span class="scroll-to-top__wrapper"><span class="scroll-to-top__inner"></span></span>
        <span class="scroll-to-top__text"> Go Back Top</span>
    </a>

    <script src="assets/js/jquery-latest.js"></script>
    <script src="assets/js/01-bootstrap.bundle.min.js"></script>
    <script src="assets/js/02-countdown.min.js"></script>
    <script src="assets/js/03-jquery.appear.min.js"></script>
    <script src="assets/js/04-jquery.nice-select.min.js"></script>
    <script src="assets/js/05-owl.carousel.min.js"></script>
    <script src="assets/js/06-jarallax.min.js"></script>
    <script src="assets/js/07-odometer.min.js"></script>
    <script src="assets/js/08-jquery-ui.js"></script>
    <script src="assets/js/09-jquery.magnific-popup.min.js"></script>
    <script src="assets/js/10-wow.js"></script>
    <script src="assets/js/11-isotope.js"></script>
    <script src="assets/js/12-jquery-sidebar-content.js"></script>
    <script src="assets/js/script.js"></script>
    
    <script>
        // Tab switching functionality
        $(document).ready(function() {
            $('.tab-btn').on('click', function() {
                var target = $(this).data('tab');
                
                // Remove active class from all tabs and buttons
                $('.tab-btn').removeClass('active-btn');
                $('.tab').removeClass('active-tab');
                
                // Add active class to clicked button and corresponding tab
                $(this).addClass('active-btn');
                $(target).addClass('active-tab');
            });
        });
        
        // Username availability check
        let usernameTimeout;
        $('#reg_username').on('input', function() {
            clearTimeout(usernameTimeout);
            const username = $(this).val();
            
            if (username.length >= 10) {
                usernameTimeout = setTimeout(function() {
                    $.ajax({
                        url: 'register.php',
                        method: 'POST',
                        data: { check_username: true, username: username },
                        dataType: 'json',
                        success: function(response) {
                            if (response.exists) {
                                $('#username-check').html('<span class="username-taken"><i class="fas fa-times-circle"></i> Username already taken</span>');
                            } else {
                                $('#username-check').html('<span class="username-available"><i class="fas fa-check-circle"></i> Username available</span>');
                            }
                        }
                    });
                }, 500);
            } else {
                $('#username-check').html('');
            }
        });
        
        // Refresh CAPTCHA function
        function refreshCaptcha() {
            $.ajax({
                url: 'register.php',
                method: 'POST',
                data: { refresh_captcha: true },
                dataType: 'json',
                success: function(response) {
                    $('#captchaDisplay').text(response.captcha);
                    // Add animation effect
                    $('#captchaDisplay').css('opacity', '0').animate({ opacity: 1 }, 300);
                },
                error: function() {
                    alert('Failed to refresh CAPTCHA. Please try again.');
                }
            });
        }
        
        // Password generator
        function generatePassword() {
            const length = 12;
            const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
            let password = "";
            
            // Ensure at least one letter and one number
            password += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".charAt(Math.floor(Math.random() * 52));
            password += "0123456789".charAt(Math.floor(Math.random() * 10));
            
            for (let i = password.length; i < length; i++) {
                password += charset.charAt(Math.floor(Math.random() * charset.length));
            }
            
            // Shuffle password
            password = password.split('').sort(() => 0.5 - Math.random()).join('');
            
            document.getElementById('password').value = password;
            document.getElementById('password').type = 'text';
        }
        
        // Toggle password visibility
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const icon = event.target.closest('button').querySelector('i');
            
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
