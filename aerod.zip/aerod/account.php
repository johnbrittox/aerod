<?php
session_start();
require_once 'dataon/config.php';
check_login();

$db = Database::getInstance();
$conn = $db->getConnection();

$user_id = $_SESSION['user_id'];
$errors = [];
$success = '';

// Fetch user data
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_profile'])) {
    try {
        $name = sanitize_input($_POST['name']);
        $username = sanitize_input($_POST['username']);
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $dob = sanitize_input($_POST['dob']);
        $phone = sanitize_input($_POST['phone']);
        $phone_alternate = sanitize_input($_POST['phone_alternate']);
        $gender = sanitize_input($_POST['gender']);
        $comments = sanitize_input($_POST['comments']);
        
        // Validate inputs
        if (empty($name) || empty($username) || empty($email) || empty($phone)) {
            throw new Exception("Required fields cannot be empty");
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }
        
        // Handle file upload
        $resume_path = $user['resume_path'];
        if (isset($_FILES['resume']) && $_FILES['resume']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['resume'];
            
            // Validate file type using finfo
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            
            if (!in_array($mime, ALLOWED_FILE_TYPES)) {
                throw new Exception("Only PDF files are allowed");
            }
            
            // Validate file size
            if ($file['size'] > MAX_FILE_SIZE) {
                throw new Exception("File size must not exceed 5MB");
            }
            
            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'resume_' . $user_id . '_' . time() . '.' . $extension;
            $target_path = UPLOAD_DIR . $filename;
            
            // Delete old file if exists
            if ($resume_path && file_exists(UPLOAD_DIR . basename($resume_path))) {
                unlink(UPLOAD_DIR . basename($resume_path));
            }
            
            // Move uploaded file
            if (!move_uploaded_file($file['tmp_name'], $target_path)) {
                throw new Exception("Failed to upload file");
            }
            
            $resume_path = 'uploads/resumes/' . $filename;
        }
        
        // Update database
        $stmt = $conn->prepare("
            UPDATE users 
            SET name = ?, username = ?, email = ?, dob = ?, phone = ?, 
                phone_alternate = ?, gender = ?, comments = ?, resume_path = ?, 
                submitted_at = NOW(), status = 'submitted'
            WHERE id = ?
        ");
        
        $stmt->execute([
            $name, $username, $email, $dob, $phone,
            $phone_alternate, $gender, $comments, $resume_path, $user_id
        ]);
        
        $success = "Profile updated successfully!";
        
        // Refresh user data
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        
    } catch (Exception $e) {
        $errors[] = $e->getMessage();
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: register.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My Account - Aero Dimensions</title>
    <meta name="description" content="Manage your Aero Dimensions account profile and information">
    <meta name="keywords" content="Aero Dimensions, Account, Profile, User Dashboard">
    
    <!-- favicons Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/favicons/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicons/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicons/favicon-16x16.png" />
    <link rel="manifest" href="assets/images/favicons/site.webmanifest" />

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,100..900;1,100..900&family=Heebo:wght@100..900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/01-bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/02-animate.min.css" />
    <link rel="stylesheet" href="assets/css/03-custom-animate.css" />
    <link rel="stylesheet" href="assets/css/05-flaticon.css" />
    <link rel="stylesheet" href="assets/css/06-font-awesome-all.css" />
    <link rel="stylesheet" href="assets/css/07-jarallax.css" />
    <link rel="stylesheet" href="assets/css/08-jquery.magnific-popup.css" />
    <link rel="stylesheet" href="assets/css/09-nice-select.css" />
    <link rel="stylesheet" href="assets/css/10-odometer.min.css" />
    <link rel="stylesheet" href="assets/css/11-owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/12-owl.theme.default.min.css" />
    <link rel="stylesheet" href="assets/css/13-jquery-ui.css" />
    <link rel="stylesheet" href="assets/css/twentytwenty.css" />

    <link rel="stylesheet" href="assets/css/module-css/01-slider.css" />
    <link rel="stylesheet" href="assets/css/module-css/02-about.css" />
    <link rel="stylesheet" href="assets/css/module-css/03-services.css" />
    <link rel="stylesheet" href="assets/css/module-css/04-testimonial.css" />
    <link rel="stylesheet" href="assets/css/module-css/05-team.css" />
    <link rel="stylesheet" href="assets/css/module-css/06-blog.css" />
    <link rel="stylesheet" href="assets/css/module-css/07-contact.css" />
    <link rel="stylesheet" href="assets/css/module-css/08-counter.css" />
    <link rel="stylesheet" href="assets/css/module-css/09-error.css" />
    <link rel="stylesheet" href="assets/css/module-css/10-faq.css" />
    <link rel="stylesheet" href="assets/css/module-css/11-footer.css" />
    <link rel="stylesheet" href="assets/css/module-css/12-page-header.css" />
    <link rel="stylesheet" href="assets/css/module-css/13-shop.css" />
    <link rel="stylesheet" href="assets/css/module-css/14-video.css" />
    <link rel="stylesheet" href="assets/css/swiper.min.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        .page-header--account {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            padding: 120px 0 80px;
            position: relative;
        }
        
        .page-header--account::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url(assets/images/backgrounds/page-header-bg.jpg);
            opacity: 0.1;
            z-index: 0;
        }
        
        .page-header__inner {
            position: relative;
            z-index: 1;
        }
        
        .page-header__title {
            color: #ffffff;
            font-size: 48px;
            font-weight: 700;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .page-header__subtitle {
            color: rgba(255, 255, 255, 0.9);
            font-size: 18px;
            text-align: center;
        }
        
        .page-header__actions {
            text-align: center;
            margin-top: 25px;
        }
        
        .btn-logout {
            background: #dc3545;
            color: white;
            padding: 12px 30px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s;
            display: inline-block;
            font-weight: 600;
        }
        
        .btn-logout:hover {
            background: #c82333;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(220, 53, 69, 0.4);
        }
        
        .btn-logout i {
            margin-right: 8px;
        }
        
        .account-section {
            padding: 80px 0;
            background: #f8f9fa;
        }
        
        .account-box {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 40px;
        }
        
        .account-box-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 30px 40px;
            border-bottom: 4px solid #ffffff;
        }
        
        .account-box-header h3 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
            color: white;
        }
        
        .account-box-header p {
            margin: 5px 0 0 0;
            opacity: 0.9;
            font-size: 14px;
        }
        
        .account-box-body {
            padding: 50px;
        }
        
        .info-box {
            background: linear-gradient(135deg, #e7f3ff 0%, #f0f7ff 100%);
            border-left: 5px solid #2a5298;
            padding: 20px 25px;
            margin-bottom: 35px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(42, 82, 152, 0.1);
        }
        
        .info-box-title {
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 10px;
            font-size: 16px;
        }
        
        .status-badge {
            display: inline-block;
            padding: 6px 18px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            margin-left: 10px;
        }
        
        .status-pending {
            background: #ffc107;
            color: #856404;
        }
        
        .status-submitted {
            background: #28a745;
            color: white;
        }
        
        .status-approved {
            background: #17a2b8;
            color: white;
        }
        
        .info-box-text {
            color: #495057;
            font-size: 14px;
            line-height: 1.8;
        }
        
        .form-group {
            margin-bottom: 30px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }
        
        .form-group label .required {
            color: #dc3545;
            margin-left: 3px;
        }
        
        .form-control {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s;
            background: #ffffff;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #2a5298;
            box-shadow: 0 0 0 3px rgba(42, 82, 152, 0.1);
        }
        
        .form-control:disabled {
            background: #f8f9fa;
            cursor: not-allowed;
            color: #6c757d;
        }
        
        .form-control-file {
            padding: 12px;
        }
        
        .form-text {
            display: block;
            margin-top: 8px;
            font-size: 13px;
            color: #6c757d;
        }
        
        .file-info {
            margin-top: 15px;
            padding: 15px 20px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 2px solid #e0e0e0;
        }
        
        .file-info-text {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            color: #495057;
        }
        
        .file-info-text i {
            font-size: 20px;
            color: #2a5298;
        }
        
        .btn-view {
            background: #28a745;
            color: white;
            padding: 8px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
            font-size: 13px;
        }
        
        .btn-view:hover {
            background: #218838;
            color: white;
            transform: translateY(-2px);
        }
        
        .btn-view i {
            margin-right: 5px;
        }
        
        .thm-btn-save {
            padding: 18px 50px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        
        .thm-btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(42, 82, 152, 0.3);
        }
        
        .thm-btn-save i {
            margin-right: 10px;
        }
        
        .section-title {
            font-size: 20px;
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 3px solid #2a5298;
            position: relative;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -3px;
            left: 0;
            width: 100px;
            height: 3px;
            background: #667eea;
        }
        
        @media (max-width: 768px) {
            .page-header__title {
                font-size: 32px;
            }
            
            .account-box-body {
                padding: 30px 20px;
            }
            
            .file-info {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .btn-view {
                width: 100%;
            }
        }
    </style>
</head>

<body class="custom-cursor">
    <div class="custom-cursor__cursor"></div>
    <div class="custom-cursor__cursor-two"></div>

    <div class="page-wrapper">
        <!--Start Main Header One-->
        <header class="main-header-one main-header-one--three">
            <!--Start Main Header One Top-->
            <div class="main-header-one__top">
                <div class="container">
                    <div class="main-header-one__top-inner">
                        <ul class="header-style1__contact">
                            <li>
                                <div class="icon">
                                    <i class="icon-clock-1"></i>
                                </div>
                                <div class="text">
                                    <p>8:00 am - 5:00 pm - Sat - Sun</p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="icon-phone-call"></i>
                                </div>
                                <div class="text">
                                    <p><a href="tel:+917994641177">+91 7994641177</a></p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="icon-placeholder"></i>
                                </div>
                                <div class="text">
                                    <p>TC 79/1029
Attukal Trippadam , 
Muttathara
Vallakadavu , po 
Trivandrum
695008
</p>
                                </div>
                            </li>
                        </ul>
                        <div class="main-header-one__top-right">
                            <div class="header-style1__social-links">
                                <a href="#"><i class="icon-facebook-app-symbol"></i></a>
                                <a href="#"><i class="icon-twitter-1"></i></a>
                                <a href="#"><i class="icon-linkedin-big-logo"></i></a>
                                <a href="#"><i class="icon-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Main Header One Top-->

            <!--Start Main Header One Bottom-->
            <div class="main-header-one__bottom">
                <nav class="main-menu">
                    <div class="main-menu__wrapper">
                        <div class="container">
                            <div class="main-menu__wrapper-inner">
                                <div class="main-header-one__bottom-left">
                                    <div class="logo-one">
                                        <a href="index.html"><img src="assets/images/resources/logo.png" alt=""></a>
                                    </div>
                                </div>
                                <div class="main-header-one__bottom-middle">
                                    <div class="main-menu__main-menu-box">
                                        <a href="#" class="mobile-nav__toggler"><i class="fa fa-bars"></i></a>
                                        <ul class="main-menu__list">
                                            <li><a href="index.html">Home</a></li>
                                            <li><a href="about.html">About Us</a></li>
                                            <li><a href="services.html">Services</a></li>
                                            <li><a href="contact.html">Contact</a></li>
                                            <li class="current"><a href="account.php">My Account</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="main-header-one__bottom-right">
                                    <div class="main-header__btn">
                                        <a class="thm-btn" href="?logout=1">
                                            <i class="fas fa-sign-out-alt"></i> Logout
                                            <span class="hover-btn hover-bx"></span>
                                            <span class="hover-btn hover-bx2"></span>
                                            <span class="hover-btn hover-bx3"></span>
                                            <span class="hover-btn hover-bx4"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            <!--End Main Header One Bottom-->
        </header>
        <!--End Main Header One-->

        <div class="stricky-header stricky-header__one stricked-menu main-menu">
            <div class="sticky-header__content"></div>
        </div>

        <!--Start Page Header-->
        <section class="page-header--account">
            <div class="container">
                <div class="page-header__inner">
                    <h2 class="page-header__title">Welcome, <?php echo htmlspecialchars($user['name']); ?>!</h2>
                    <p class="page-header__subtitle">Manage your profile information and account settings</p>
                    <div class="page-header__actions">
                        <a href="?logout=1" class="btn-logout">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <!--End Page Header-->

        <!--Start Account Section-->
        <section class="account-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 offset-lg-1">
                        <!-- Account Status Box -->
                        <div class="info-box wow fadeInUp" data-wow-delay="0.1s">
                            <div class="info-box-title">
                                <i class="fas fa-info-circle"></i> Account Status: 
                                <span class="status-badge status-<?php echo $user['status']; ?>">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </div>
                            <div class="info-box-text">
                                <strong>Account Created:</strong> <?php echo date('F d, Y', strtotime($user['created_at'])); ?>
                                <?php if ($user['submitted_at']): ?>
                                    | <strong>Last Updated:</strong> <?php echo date('F d, Y h:i A', strtotime($user['submitted_at'])); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Profile Form Box -->
                        <div class="account-box wow fadeInUp" data-wow-delay="0.2s">
                            <div class="account-box-header">
                                <h3><i class="fas fa-user-edit"></i> Profile Information</h3>
                                <p>Update your personal information and resume</p>
                            </div>
                            
                            <div class="account-box-body">
                                <form method="POST" action="" enctype="multipart/form-data" id="profileForm">
                                    <!-- Personal Information Section -->
                                    <div class="section-title">
                                        <i class="fas fa-user"></i> Personal Information
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Full Name <span class="required">*</span></label>
                                                <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" required placeholder="Enter your full name">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Username (Phone) <span class="required">*</span></label>
                                                <input type="text" name="username_display" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                                                <small class="form-text"><i class="fas fa-lock"></i> Username cannot be changed for security reasons</small>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Email Address <span class="required">*</span></label>
                                                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required placeholder="Enter your email address">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Date of Birth</label>
                                                <input type="date" name="dob" class="form-control" value="<?php echo $user['dob']; ?>">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Phone Number <span class="required">*</span></label>
                                                <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>" pattern="[0-9]{10,15}" required placeholder="Enter 10-15 digit phone number">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Alternate Phone</label>
                                                <input type="text" name="phone_alternate" class="form-control" value="<?php echo htmlspecialchars($user['phone_alternate'] ?? ''); ?>" pattern="[0-9]{10,15}" placeholder="Enter alternate phone number">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Gender</label>
                                                <select name="gender" class="form-control">
                                                    <option value="">Select Gender</option>
                                                    <option value="Male" <?php echo $user['gender'] === 'Male' ? 'selected' : ''; ?>>Male</option>
                                                    <option value="Female" <?php echo $user['gender'] === 'Female' ? 'selected' : ''; ?>>Female</option>
                                                    <option value="Other" <?php echo $user['gender'] === 'Other' ? 'selected' : ''; ?>>Other</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Resume Upload Section -->
                                    <div class="section-title" style="margin-top: 40px;">
                                        <i class="fas fa-file-upload"></i> Resume Upload
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Upload Resume (PDF only, max 40MB)</label>
                                                <input type="file" name="resume" class="form-control form-control-file" accept=".pdf">
                                                <small class="form-text"><i class="fas fa-info-circle"></i> Only PDF files are accepted. Maximum file size: 40MB</small>
                                                
                                                <?php if ($user['resume_path']): ?>
                                                    <div class="file-info">
                                                        <div class="file-info-text">
                                                            <i class="fas fa-file-pdf"></i>
                                                            <span><strong>Current Resume:</strong> <?php echo basename($user['resume_path']); ?></span>
                                                        </div>
                                                        <a href="<?php echo htmlspecialchars($user['resume_path']); ?>" target="_blank" class="btn-view">
                                                            <i class="fas fa-eye"></i> View Resume
                                                        </a>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Additional Information Section -->
                                    <div class="section-title" style="margin-top: 40px;">
                                        <i class="fas fa-comment-alt"></i> Additional Information
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Comments / Additional Information</label>
                                               <textarea name="comments" class="form-control" rows="6" placeholder="Enter any additional comments, qualifications, experience, or information you'd like to share"><?php echo htmlspecialchars($user['comments'] ?? ''); ?></textarea>
                                                <small class="form-text"><i class="fas fa-info-circle"></i> You can include your qualifications, experience, skills, or any other relevant information</small>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <input type="hidden" name="username" value="<?php echo htmlspecialchars($user['username']); ?>">
                                    
                                    <div style="margin-top: 40px; text-align: center;">
                                        <button type="submit" name="save_profile" class="thm-btn-save">
                                            <i class="fas fa-save"></i> Save Profile
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Account Section-->

        <!--Start Site Footer-->
        <footer class="site-footer site-footer--three">
            <div class="site-footer--three__pattern" style="background-image: url(assets/images/pattern/footer-v3-pattern.png);"></div>
            <!--Start Site Footer Top-->
            <div class="site-footer__top">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".0s">
                            <div class="footer-widget__single footer-widget__about">
                                <div class="site-footer__logo">
                                    <a href="index.html"><img src="assets/images/resources/logo2.png" alt=""></a>
                                </div>
                                <div class="footer-widget__about-text">
                                    <p>AeroDimensions provides innovative engineering solutions, specializing in aerospace and industrial technologies.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".1s">
                            <div class="footer-widget__single footer-widget__services">
                                <div class="title-box">
                                    <h2>Quick Links</h2>
                                    <div class="line"></div>
                                </div>
                                <ul class="footer-widget__services-list">
                                    <li><a href="index.html"><span class="icon-right-chevron"></span> Home</a></li>
                                    <li><a href="about.html"><span class="icon-right-chevron"></span> About Us</a></li>
                                    <li><a href="services.html"><span class="icon-right-chevron"></span> Services</a></li>
                                    <li><a href="contact.html"><span class="icon-right-chevron"></span> Contact</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".3s">
                            <div class="footer-widget__single footer-widget__contact">
                                <div class="title-box">
                                    <h2>Contact Info</h2>
                                    <div class="line"></div>
                                </div>
                                <ul class="footer-widget__contact-list">
                                    <li>
                                        <div class="icon-box">
                                            <span class="icon-placeholder"></span>
                                        </div>
                                        <div class="text-box">
                                            <p>TC 79/1029 ,
 Attukal Trippadam ,
Muttathara ,<br>
Vallakadavu po 
Trivandrum ,
695008</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay=".3s">
                            <div class="footer-widget__single footer-widget__contact">
                                <div class="title-box">
                                    <h2>Contact Info</h2>
                                    <div class="line"></div>
                                </div>
                                <ul class="footer-widget__contact-list">
                                    <li>
                                        <div class="icon-box">
                                            <span class="icon-phone-call"></span>
                                        </div>
                                        <div class="text-box"> 
    <p><a href="tel:+917994641177">+91 79946 41177</a></p>
    <p><a href="tel:+917356323713">+91 73563 23713</a></p>
    <p><a href="tel:+918301921693">+91 83019 21693</a></p>
</div>
                                    </li>
                                    <li>
                                        <div class="icon-box">
                                            <span class="icon-envelope"></span>
                                        </div>
                                        <div class="text-box">
                                            
                                            <p><a href="mailto:aerokerala2025@gmail.com">aerokerala2025@gmail.com</a></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Site Footer Top-->

            <!--Start Site Footer Bottom-->
            <div class="site-footer__bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="site-footer__bottom-inner">
                                <div class="site-footer__copyright">
                                    <p>Copyright © 2025 <a href="index.html">AeroDimensions</a>. All Rights Reserved.</p>
                                </div>
                                <ul class="site-footer__bottom-menu">
                                    <li style="color: white;">Design & Developed by<a href="https://neowebtec.com/"> Neoweb Technologies</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Site Footer Bottom-->
        </footer>
        <!--End Site Footer-->
    </div>

    <div class="mobile-nav__wrapper">
        <div class="mobile-nav__overlay mobile-nav__toggler"></div>
        <div class="mobile-nav__content">
            <span class="mobile-nav__close mobile-nav__toggler">
                <i class="fa fa-times"></i>
            </span>
            <div class="logobox">
                <a href="index.html" aria-label="logo image">
                    <img src="assets/images/resources/logo2.png" alt="Logo" />
                </a>
            </div>
            <div class="mobile-nav__container"></div>
            <ul class="mobile-nav__contact list-unstyled">
                <li>
                    <i class="icon-envelope"></i>
                    <a href="mailto:aerokerala2025@gmail.com">aerokerala2025@gmail.com</a>
                </li>
                <li>
                    <i class="icon-phone-call"></i>
                    <a href="tel:+917994641177">+91 7994641177</a>
                </li>
            </ul>
            <div class="mobile-nav__top">
                <div class="mobile-nav__social">
                    <a href="#" class="icon-facebook-app-symbol"></a>
                    <a href="#" class="icon-twitter-1"></a>
                    <a href="#" class="icon-instagram"></a>
                    <a href="#" class="icon-pinterest"></a>
                </div>
            </div>
        </div>
    </div>

    <div class="search-popup">
        <button class="close-search" aria-label="close search box" title="close search box">
            <span class="icon-plus-1"></span>
        </button>
        <form action="#" method="post">
            <div class="search-popup__group">
                <input type="text" name="search-field" id="searchField" placeholder="Search Here..." required>
                <button type="submit" aria-label="search products" title="search products">
                    <i class="icon-search-interface-symbol"></i>
                </button>
            </div>
        </form>
    </div>

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top">
        <span class="scroll-to-top__wrapper"><span class="scroll-to-top__inner"></span></span>
        <span class="scroll-to-top__text"> Go Back Top</span>
    </a>

    <script src="assets/js/jquery-latest.js"></script>
    <script src="assets/js/01-bootstrap.bundle.min.js"></script>
    <script src="assets/js/02-countdown.min.js"></script>
    <script src="assets/js/03-jquery.appear.min.js"></script>
    <script src="assets/js/04-jquery.nice-select.min.js"></script>
    <script src="assets/js/05-owl.carousel.min.js"></script>
    <script src="assets/js/06-jarallax.min.js"></script>
    <script src="assets/js/07-odometer.min.js"></script>
    <script src="assets/js/08-jquery-ui.js"></script>
    <script src="assets/js/09-jquery.magnific-popup.min.js"></script>
    <script src="assets/js/10-wow.js"></script>
    <script src="assets/js/11-isotope.js"></script>
    <script src="assets/js/12-jquery-sidebar-content.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        // SweetAlert2 notifications
        <?php if ($success): ?>
        Swal.fire({
            title: 'Success!',
            text: '<?php echo addslashes($success); ?>',
            icon: 'success',
            confirmButtonColor: '#2a5298',
            confirmButtonText: 'OK',
            timer: 3000,
            timerProgressBar: true
        });
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
        Swal.fire({
            title: 'Error!',
            html: '<?php echo implode("<br>", array_map("addslashes", $errors)); ?>',
            icon: 'error',
            confirmButtonColor: '#dc3545',
            confirmButtonText: 'OK'
        });
        <?php endif; ?>
        
        // Form validation before submit
        $('#profileForm').on('submit', function(e) {
            var phone = $('input[name="phone"]').val();
            var phonePattern = /^[0-9]{10,15}$/;
            
            if (!phonePattern.test(phone)) {
                e.preventDefault();
                Swal.fire({
                    title: 'Validation Error!',
                    text: 'Phone number must be 10-15 digits',
                    icon: 'warning',
                    confirmButtonColor: '#ffc107',
                    confirmButtonText: 'OK'
                });
                return false;
            }
        });
        
        // Logout confirmation
        $('a[href*="logout"]').on('click', function(e) {
            e.preventDefault();
            var href = $(this).attr('href');
            
            Swal.fire({
                title: 'Logout Confirmation',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, Logout',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = href;
                }
            });
        });
    </script>
</body>
</html>
