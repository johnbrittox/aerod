<?php
require_once '../dataon/config.php';

if (isset($_SESSION['admin_id'])) {
    header("Location: admin.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $username = sanitize_input($_POST['username']);
        $password = $_POST['password'];
        $ip = $_SERVER['REMOTE_ADDR'];
        
        if (empty($username) || empty($password)) {
            throw new Exception("Username and password are required");
        }
        
        $db = Database::getInstance();
        $conn = $db->getConnection();
        
        // Check login attempts
        if (!check_login_attempts($username, $ip, $conn)) {
            throw new Exception("Too many failed login attempts. Please try again in 30 minutes.");
        }
        
        $stmt = $conn->prepare("SELECT id, username, password FROM admin WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();
        
        if ($admin && password_verify($password, $admin['password'])) {
            log_login_attempt($username, $ip, 1, $conn);
            
            // Update last login
            $stmt = $conn->prepare("UPDATE admin SET last_login = NOW() WHERE id = ?");
            $stmt->execute([$admin['id']]);
            
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_last_activity'] = time();
            
            header("Location: admin.php");
            exit();
        } else {
            log_login_attempt($username, $ip, 0, $conn);
            throw new Exception("Invalid username or password");
        }
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Aero Dimensions</title>
    
    <link rel="stylesheet" href="assets/css/01-bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    
    <style>
        .admin-login-container {
            min-height: 100vh;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .admin-login-box {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 50px;
            max-width: 450px;
            width: 100%;
        }
        
        .admin-login-box h2 {
            text-align: center;
            margin-bottom: 10px;
            color: #1e3c72;
        }
        
        .admin-login-box p {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #1e3c72;
            box-shadow: 0 0 0 3px rgba(30, 60, 114, 0.1);
        }
        
        .btn-admin-login {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }
        
        .btn-admin-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(30, 60, 114, 0.4);
        }
        
        .alert-danger {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .admin-icon {
            text-align: center;
            font-size: 60px;
            color: #1e3c72;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="admin-login-container">
        <div class="admin-login-box">
            <div class="admin-icon">🔐</div>
            <h2>Admin Portal</h2>
            <p>Aero Dimensions Management System</p>
            
            <?php if ($error): ?>
                <div class="alert-danger">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['timeout'])): ?>
                <div class="alert-danger">
                    Session expired. Please login again.
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" placeholder="Enter admin username" required autofocus>
                </div>
                
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter password" required>
                </div>
                
                <button type="submit" class="btn-admin-login">Login to Dashboard</button>
            </form>
        </div>
    </div>
</body>
</html>