<?php
require_once '../dataon/config.php';
check_admin_login();

$db = Database::getInstance();
$conn = $db->getConnection();

// Handle user deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    $user_id = (int)$_POST['user_id'];
    
    try {
        // Get user data first to delete resume file
        $stmt = $conn->prepare("SELECT resume_path FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user_data = $stmt->fetch();
        
        // Delete resume file if exists
        if ($user_data && !empty($user_data['resume_path'])) {
            $file_path = '../' . $user_data['resume_path'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
        
        // Delete user from database
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        
        $delete_success = "User deleted successfully!";
    } catch (Exception $e) {
        $delete_error = "Failed to delete user: " . $e->getMessage();
    }
}

// Pagination settings
$records_per_page = 20;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

// Search functionality
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$search_query = '';
$params = [];

if (!empty($search)) {
    $search_query = " WHERE name LIKE ? OR username LIKE ? OR phone LIKE ? OR email LIKE ?";
    $search_param = "%{$search}%";
    $params = [$search_param, $search_param, $search_param, $search_param];
}

// Get total records with search
$count_sql = "SELECT COUNT(*) as total FROM users" . $search_query;
$stmt = $conn->prepare($count_sql);
if (!empty($params)) {
    $stmt->execute($params);
} else {
    $stmt->execute();
}
$total_records = $stmt->fetch()['total'];
$total_pages = ceil($total_records / $records_per_page);

// Fetch users with search
$sql = "
    SELECT id, name, username, email, phone, gender, status, resume_path, created_at, submitted_at 
    FROM users 
    {$search_query}
    ORDER BY created_at DESC 
    LIMIT ? OFFSET ?
";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $params[] = $records_per_page;
    $params[] = $offset;
    $stmt->execute($params);
} else {
    $stmt->bindValue(1, $records_per_page, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
}
$users = $stmt->fetchAll();

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    $stmt = $conn->prepare("SELECT password FROM admin WHERE id = ?");
    $stmt->execute([$_SESSION['admin_id']]);
    $admin = $stmt->fetch();
    
    if (password_verify($current_password, $admin['password'])) {
        if ($new_password === $confirm_password && strlen($new_password) >= 8) {
            $hashed = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE admin SET password = ? WHERE id = ?");
            $stmt->execute([$hashed, $_SESSION['admin_id']]);
            $password_success = "Password changed successfully!";
        } else {
            $password_error = "Passwords don't match or too short (min 8 characters)";
        }
    } else {
        $password_error = "Current password is incorrect";
    }
}

// Handle username change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_username'])) {
    $new_username = sanitize_input($_POST['new_username']);
    $password = $_POST['password'];
    
    $stmt = $conn->prepare("SELECT password FROM admin WHERE id = ?");
    $stmt->execute([$_SESSION['admin_id']]);
    $admin = $stmt->fetch();
    
    if (password_verify($password, $admin['password'])) {
        $stmt = $conn->prepare("UPDATE admin SET username = ? WHERE id = ?");
        $stmt->execute([$new_username, $_SESSION['admin_id']]);
        $_SESSION['admin_username'] = $new_username;
        $username_success = "Username changed successfully!";
    } else {
        $username_error = "Password is incorrect";
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: admin_login.php");
    exit();
}

// Helper function to build pagination URLs
function build_url($page, $search = '') {
    $url = "?page={$page}";
    if (!empty($search)) {
        $url .= "&search=" . urlencode($search);
    }
    return $url;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Aero Dimensions</title>
    
    <link rel="stylesheet" href="assets/css/01-bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/06-font-awesome-all.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
        }
        
        .admin-navbar {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 20px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .admin-navbar h1 {
            font-size: 24px;
            margin: 0;
        }
        
        .admin-navbar .admin-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .btn-settings {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        
        .btn-logout {
            background: #dc3545;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
        }
        
        .admin-container {
            padding: 30px;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .stat-card h3 {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
        }
        
        .stat-card .number {
            font-size: 32px;
            font-weight: bold;
            color: #1e3c72;
        }
        
        .search-container {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .search-form {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .search-input {
            flex: 1;
            padding: 12px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #2a5298;
            box-shadow: 0 0 0 3px rgba(42, 82, 152, 0.1);
        }
        
        .btn-search {
            padding: 12px 30px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-search:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(42, 82, 152, 0.3);
        }
        
        .btn-clear {
            padding: 12px 30px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-clear:hover {
            background: #5a6268;
            color: white;
        }
        
        .search-info {
            margin-top: 15px;
            padding: 12px 20px;
            background: #e7f3ff;
            border-left: 4px solid #2a5298;
            border-radius: 5px;
            color: #1e3c72;
            font-weight: 600;
        }
        
        .users-table-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .table-header {
            padding: 20px 30px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .table-header h2 {
            margin: 0;
            color: #333;
        }
        
        .export-btn {
            padding: 10px 20px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 600;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: #f8f9fa;
        }
        
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #e0e0e0;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        tbody tr:hover {
            background: #f8f9fa;
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-submitted {
            background: #d4edda;
            color: #155724;
        }
        
        .status-reviewed {
            background: #d1ecf1;
            color: #0c5460;
        }
        
        .btn-view {
            background: #28a745;
            color: white;
            padding: 6px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 12px;
            margin-right: 5px;
            display: inline-block;
        }
        
        .btn-view:hover {
            background: #218838;
            color: white;
        }
        
        .btn-delete {
            background: #dc3545;
            color: white;
            padding: 6px 15px;
            border-radius: 5px;
            border: none;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-delete:hover {
            background: #c82333;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .pagination a {
            padding: 10px 15px;
            background: #1e3c72;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .pagination a:hover {
            background: #2a5298;
        }
        
        .pagination a.active {
            background: #667eea;
        }
        
        .pagination a.disabled {
            background: #ccc;
            pointer-events: none;
            cursor: not-allowed;
        }
        
        .no-results {
            padding: 40px;
            text-align: center;
            color: #666;
        }
        
        .no-results i {
            font-size: 48px;
            margin-bottom: 15px;
            color: #ccc;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            padding: 40px;
            border-radius: 10px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-content h3 {
            margin-bottom: 20px;
            color: #1e3c72;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
        }
        
        .btn-primary {
            padding: 12px 30px;
            background: #1e3c72;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 10px;
        }
        
        .btn-secondary {
            padding: 12px 30px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @media (max-width: 768px) {
            .search-form {
                flex-direction: column;
            }
            
            .btn-search, .btn-clear {
                width: 100%;
            }
            
            .table-header {
                flex-direction: column;
                gap: 15px;
            }
            
            table {
                font-size: 14px;
            }
            
            th, td {
                padding: 10px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="admin-navbar">
        <h1>🚀 Aero Dimensions Admin Dashboard</h1>
        <div class="admin-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username'] ?? ''); ?></span>
            <button class="btn-settings" onclick="openSettingsModal()">⚙️ Settings</button>
            <a href="?logout=1" class="btn-logout">Logout</a>
        </div>
    </div>
    
    <div class="admin-container">
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Applications</h3>
                <div class="number"><?php echo $total_records; ?></div>
            </div>
            
            <div class="stat-card">
                <h3>Pending Review</h3>
                <div class="number">
                    <?php
                    $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE status = 'pending'");
                    echo $stmt->fetch()['count'];
                    ?>
                </div>
            </div>
            
            <div class="stat-card">
                <h3>Submitted</h3>
                <div class="number">
                    <?php
                    $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE status = 'submitted'");
                    echo $stmt->fetch()['count'];
                    ?>
                </div>
            </div>
            
            <div class="stat-card">
                <h3>Today's Registrations</h3>
                <div class="number">
                    <?php
                    $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE DATE(created_at) = CURDATE()");
                    echo $stmt->fetch()['count'];
                    ?>
                </div>
            </div>
        </div>
        
        <!-- Search Container -->
        <div class="search-container">
            <form method="GET" action="" class="search-form">
                <input 
                    type="text" 
                    name="search" 
                    class="search-input" 
                    placeholder="🔍 Search by Name, Phone, Email, or Username..." 
                    value="<?php echo htmlspecialchars($search); ?>"
                >
                <button type="submit" class="btn-search">
                    <i class="fas fa-search"></i> Search
                </button>
                <?php if (!empty($search)): ?>
                    <a href="?" class="btn-clear">
                        <i class="fas fa-times"></i> Clear
                    </a>
                <?php endif; ?>
            </form>
            
            <?php if (!empty($search)): ?>
                <div class="search-info">
                    <i class="fas fa-info-circle"></i> 
                    Showing results for: <strong>"<?php echo htmlspecialchars($search); ?>"</strong> 
                    (<?php echo $total_records; ?> results found)
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Users Table -->
        <div class="users-table-container">
            <div class="table-header">
                <h2>All Applications</h2>
                <a href="export.php<?php echo !empty($search) ? '?search=' . urlencode($search) : ''; ?>" class="export-btn">
                    <i class="fas fa-download"></i> Export to Excel
                </a>
            </div>
            
            <?php if (count($users) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Gender</th>
                        <th>Status</th>
                        <th>Resume</th>
                        <th>Created</th>
                        <th>Submitted</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo $user['id']; ?></td>
                        <td><?php echo htmlspecialchars($user['name'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($user['username'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($user['email'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($user['phone'] ?? ''); ?></td>
                        <td><?php echo $user['gender'] ?? '-'; ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $user['status']; ?>">
                                <?php echo ucfirst($user['status']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if (!empty($user['resume_path'])): ?>
                                <a href="/<?php echo htmlspecialchars($user['resume_path']); ?>" target="_blank" class="btn-view">
                                    <i class="fas fa-eye"></i> View
                                </a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                        <td><?php echo $user['submitted_at'] ? date('M d, Y', strtotime($user['submitted_at'])) : '-'; ?></td>
                        <td>
                            <div class="action-buttons">
                                <button 
                                    class="btn-delete" 
                                    onclick="confirmDelete(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars(addslashes($user['name'] ?? '')); ?>')"
                                >
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <a href="<?php echo build_url(1, $search); ?>" class="<?php echo $page <= 1 ? 'disabled' : ''; ?>">
                    <i class="fas fa-angle-double-left"></i> First
                </a>
                <a href="<?php echo build_url(max(1, $page - 1), $search); ?>" class="<?php echo $page <= 1 ? 'disabled' : ''; ?>">
                    <i class="fas fa-angle-left"></i> Previous
                </a>
                
                <?php
                $start = max(1, $page - 2);
                $end = min($total_pages, $page + 2);
                
                for ($i = $start; $i <= $end; $i++):
                ?>
                    <a href="<?php echo build_url($i, $search); ?>" class="<?php echo $i == $page ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
                
                <a href="<?php echo build_url(min($total_pages, $page + 1), $search); ?>" class="<?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                    Next <i class="fas fa-angle-right"></i>
                </a>
                <a href="<?php echo build_url($total_pages, $search); ?>" class="<?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                    Last <i class="fas fa-angle-double-right"></i>
                </a>
            </div>
            <?php endif; ?>
            
            <?php else: ?>
            <div class="no-results">
                <i class="fas fa-search"></i>
                <h3>No Results Found</h3>
                <p>No applications match your search criteria "<?php echo htmlspecialchars($search); ?>"</p>
                <a href="?" class="btn-clear" style="margin-top: 15px;">
                    <i class="fas fa-arrow-left"></i> Back to All Applications
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Settings Modal -->
    <div id="settingsModal" class="modal">
        <div class="modal-content">
            <h3>⚙️ Admin Settings</h3>
            
            <?php if (isset($password_success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $password_success; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($password_error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $password_error; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($username_success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $username_success; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($username_error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $username_error; ?>
                </div>
            <?php endif; ?>
            
            <!-- Change Password Form -->
            <form method="POST" action="">
                <h4 style="margin-bottom: 15px;">🔒 Change Password</h4>
                <div class="form-group">
                    <label>Current Password</label>
                    <input type="password" name="current_password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>New Password</label>
                    <input type="password" name="new_password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Confirm New Password</label>
                    <input type="password" name="confirm_password" class="form-control" required>
                </div>
                <button type="submit" name="change_password" class="btn-primary">
                    <i class="fas fa-save"></i> Change Password
                </button>
            </form>
            
            <hr style="margin: 30px 0;">
            
            <!-- Change Username Form -->
            <form method="POST" action="">
                <h4 style="margin-bottom: 15px;">👤 Change Username</h4>
                <div class="form-group">
                    <label>New Username</label>
                    <input type="text" name="new_username" class="form-control" value="<?php echo htmlspecialchars($_SESSION['admin_username'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label>Confirm with Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" name="change_username" class="btn-primary">
                    <i class="fas fa-save"></i> Change Username
                </button>
                <button type="button" class="btn-secondary" onclick="closeSettingsModal()">
                    <i class="fas fa-times"></i> Close
                </button>
            </form>
        </div>
    </div>
    
    <!-- Hidden Form for Delete -->
    <form id="deleteForm" method="POST" action="" style="display: none;">
        <input type="hidden" name="user_id" id="delete_user_id">
        <input type="hidden" name="delete_user" value="1">
    </form>
    
    <script src="../assets/js/jquery-latest.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        function openSettingsModal() {
            document.getElementById('settingsModal').classList.add('active');
        }
        
        function closeSettingsModal() {
            document.getElementById('settingsModal').classList.remove('active');
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('settingsModal');
            if (event.target === modal) {
                closeSettingsModal();
            }
        }
        
        // Auto-open settings modal if there's a message
        <?php if (isset($password_success) || isset($password_error) || isset($username_success) || isset($username_error)): ?>
        openSettingsModal();
        <?php endif; ?>
        
        // Delete confirmation using SweetAlert2
        function confirmDelete(userId, userName) {
            Swal.fire({
                title: 'Are you sure?',
                html: `You are about to delete user: <br><strong>${userName}</strong><br><br>This action cannot be undone!`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: '<i class="fas fa-trash"></i> Yes, delete it!',
                cancelButtonText: '<i class="fas fa-times"></i> Cancel',
                reverseButtons: true,
                focusCancel: true
            }).then((result) => {
                if (result.isConfirmed) {
                    // Set the user ID and submit the form
                    document.getElementById('delete_user_id').value = userId;
                    document.getElementById('deleteForm').submit();
                }
            });
        }
        
        // Show success message after deletion
        <?php if (isset($delete_success)): ?>
        Swal.fire({
            title: 'Deleted!',
            text: '<?php echo addslashes($delete_success); ?>',
            icon: 'success',
            confirmButtonColor: '#28a745',
            timer: 3000,
            timerProgressBar: true
        });
        <?php endif; ?>
        
        // Show error message if deletion failed
        <?php if (isset($delete_error)): ?>
        Swal.fire({
            title: 'Error!',
            text: '<?php echo addslashes($delete_error); ?>',
            icon: 'error',
            confirmButtonColor: '#dc3545'
        });
        <?php endif; ?>
    </script>
</body>
</html>
