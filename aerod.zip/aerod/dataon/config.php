<?php
session_start();

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'adminaerodimen_aeroondata');
define('DB_PASS', 'q4qU)#g!tu)We8)y');
define('DB_NAME', 'adminaerodimen_aeroondata');

// Site Configuration
define('SITE_URL', 'https://www.aerodimensions.com');
define('UPLOAD_DIR', dirname(__DIR__) . '/uploads/resumes/');
define('MAX_FILE_SIZE', 41943040); // 40MB
define('UPLOAD_URL', '/uploads/resumes/');

define('ALLOWED_FILE_TYPES', ['application/pdf']);

// Security Configuration
define('CAPTCHA_LENGTH', 6);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_TIMEOUT', 900); // 15 minutes

// Create database connection
class Database {
    private static $instance = null;
    private $conn;
    
    private function __construct() {
        try {
            $this->conn = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch(PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }
    
    public static function getInstance() {
        if(self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->conn;
    }
}

// Security Functions
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

function generate_captcha() {
    $characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $captcha = '';
    for ($i = 0; $i < CAPTCHA_LENGTH; $i++) {
        $captcha .= $characters[rand(0, strlen($characters) - 1)];
    }
    $_SESSION['captcha'] = $captcha;
    return $captcha;
}

function verify_captcha($input) {
    return isset($_SESSION['captcha']) && strtoupper($input) === $_SESSION['captcha'];
}

function check_login() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
        header("Location: register.php");
        exit();
    }
    
    // Check session timeout
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > LOGIN_TIMEOUT)) {
        session_unset();
        session_destroy();
        header("Location: register.php?timeout=1");
        exit();
    }
    $_SESSION['last_activity'] = time();
}

function check_admin_login() {
    if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_username'])) {
        header("Location: admin_login.php");
        exit();
    }
    
    if (isset($_SESSION['admin_last_activity']) && (time() - $_SESSION['admin_last_activity'] > LOGIN_TIMEOUT)) {
        session_unset();
        session_destroy();
        header("Location: admin_login.php?timeout=1");
        exit();
    }
    $_SESSION['admin_last_activity'] = time();
}

function is_phone_blocked($phone, $conn) {
    $stmt = $conn->prepare("SELECT id FROM blocked_numbers WHERE phone = ?");
    $stmt->execute([$phone]);
    return $stmt->fetch() !== false;
}

function check_login_attempts($username, $ip, $conn) {
    $stmt = $conn->prepare("
        SELECT COUNT(*) as attempts 
        FROM login_attempts 
        WHERE username = ? 
        AND ip_address = ? 
        AND success = 0 
        AND attempt_time > DATE_SUB(NOW(), INTERVAL 30 MINUTE)
    ");
    $stmt->execute([$username, $ip]);
    $result = $stmt->fetch();
    return $result['attempts'] < MAX_LOGIN_ATTEMPTS;
}

function log_login_attempt($username, $ip, $success, $conn) {
    $stmt = $conn->prepare("INSERT INTO login_attempts (username, ip_address, success) VALUES (?, ?, ?)");
    $stmt->execute([$username, $ip, $success]);
}

// Create upload directory if not exists
if (!file_exists(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}
?>